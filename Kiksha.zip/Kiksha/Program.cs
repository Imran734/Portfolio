﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace KikshaCom
{
    class Program
    {
        static string url = "https://kiksha.com/";
        static IWebDriver driver = new ChromeDriver();
        static string actualtitle = "Online shopping in BD @ kiksha.com: Fashion items, Mobiles,Jewellery, Home appliances, Flowers, Gifts & lifestyle products";
        static void Main(string[] args)
        {
            if (TC_01_CheckLoadingofThePage())
            {
                Console.WriteLine("TC_01_CheckLoadingofThePage: Passed");
            }

            else
                Console.WriteLine("TC_01_CheckLoadingofThePage: Failed");
            if (TC_02_CheckOfferZoneLink())
            {
                Console.WriteLine("TC_02_CheckOfferZoneLink: Passed");
            }

            else
                Console.WriteLine("TC_02_CheckOfferZoneLink: Failed");
            if (TC_03_CheckSearch())
            {
                Console.WriteLine("TC_03_CheckSearch: Passed");
            }

            else
                Console.WriteLine("TC_03_CheckSearch: Failed");
            if (TC_04_LoginWithValidInput())
            {
                Console.WriteLine("TC_04_LoginWithValidInput: Passed");
            }

            else
                Console.WriteLine("TC_04_LoginWithValidInput: Failed");
            if (TC_06_CheckNewsletter())
            {
                Console.WriteLine("TC_06_CheckNewsletter: Passed");
            }

            else
                Console.WriteLine("TC_06_CheckNewsletter: Failed");
            if (TC_07_CheckMenOption())
            {
                Console.WriteLine("TC_07_CheckMenOption: Passed");
            }

            else
                Console.WriteLine("TC_07_CheckMenOption: Failed");
            if (TC_08_CheckAllOption())
            {
                Console.WriteLine("TC_08_CheckAllOption: Passed");
            }

            else
                Console.WriteLine("TC_08_CheckAllOption: Failed");
            if (TC_09_CheckWomenOption())
            {
                Console.WriteLine("TC_09_CheckWomenOption: Passed");
            }
            else
                Console.WriteLine("TC_09_CheckWomenOption: Failed");
            if(TC_10_CheckkidsOption())
            {
                Console.WriteLine("TC_10_CheckkidsOption: Passed");
            }
            else
                Console.WriteLine("TC_10_CheckkidsOption: Failed");
            if (TC_11_CheckElectronicsOption())
            {
                Console.WriteLine("TC_11_CheckElectronicsOption: Passed");
            }
            else
                Console.WriteLine("TC_11_CheckElectronicsOption: Failed");
            if (TC_12_CheckLivingOption())
            {
                Console.WriteLine("TC_12_CheckLivingOption: Passed");
            }
            else
                Console.WriteLine("TC_12_CheckLivingOption: Failed");
            if (TC_05_CheckCopyrightLink())
            {
                Console.WriteLine("TC_05_CheckCopyrightLink: Passed");
            }

            else
                Console.WriteLine("TC_05_CheckCopyrightLink: Failed");
        }

        static public bool TC_01_CheckLoadingofThePage()
        {
            driver.Navigate().GoToUrl(url);
            string windowTitle = driver.Title;

            if (actualtitle == windowTitle)
            {
                return true;
            }

            else
                return false;

        }

        static public bool TC_02_CheckOfferZoneLink()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                IWebElement link = driver.FindElement(By.ClassName("blink_me"));
                link.Click();

                string windowTitle = driver.Title;

                if (windowTitle == "Offer Zone")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_03_CheckSearch()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.FindElement(By.Id("search")).SendKeys("watch");
                IWebElement searchbutton = driver.FindElement(By.ClassName("search-icon"));
                searchbutton.Click();

                string windowTitle = driver.Title;

                if (windowTitle == "Search results for: 'watch'")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_04_LoginWithValidInput()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                IWebElement loginlink = driver.FindElement(By.ClassName("top-link-myaccountlog"));
                loginlink.Click();
                driver.FindElement(By.Id("email")).SendKeys("01739862386");
                IWebElement loginbutton = driver.FindElement(By.Id("send2"));
                loginbutton.Click();
                Thread.Sleep(10000);
                if (!driver.FindElement(By.Id("pass")).Displayed)
                    Thread.Sleep(30000);
                else
                    driver.FindElement(By.Id("pass")).SendKeys("Golam-734");
                //driver.FindElement(By.Name("login[password]")).SendKeys("seleniumtest");
                //driver.FindElement(By.XPath("//input[@id='pass']")).Click();
                //Thread.Sleep(5000);
                IWebElement loginbutton1 = driver.FindElement(By.Id("send-login"));
                loginbutton1.Click();

                string loginname = driver.Title;

                if (loginname == actualtitle)
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_05_CheckCopyrightLink()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                IWebElement link = driver.FindElement(By.ClassName("coppyright"));
                link.Click();

                var _windowsList = new List<String>(driver.WindowHandles);
                driver.SwitchTo().Window(_windowsList[1]);
                string windowTitle = driver.Title;

                if (windowTitle == "Zero Gravity Ventures | Startup e-Commerce Venture")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_06_CheckNewsletter()
        {
            driver.Navigate().GoToUrl("https://kiksha.com/newsletter/");
            driver.FindElement(By.Id("newsletter1")).SendKeys("sqt_test@gmail.com");
            IWebElement subscribebutton = driver.FindElement(By.ClassName("subscribe"));
            subscribebutton.Click();
            //error-msg
            string error = driver.FindElement(By.ClassName("error-msg")).Text;
            Console.WriteLine(error);

            if (error == "There was a problem with the subscription: This email address is already assigned to another user.")
                return true;
            else
                return false;
        }
        static public bool TC_07_CheckMenOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.Navigate().GoToUrl("https://kiksha.com/men/");

                string windowTitle = driver.Title;

                if (windowTitle == "MEN")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_08_CheckAllOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                IWebElement all = driver.FindElement(By.Name("cat"));
                all.Click();

                string windowTitle = driver.Title;

                if (actualtitle == windowTitle)
                {
                    return true;
                }

                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_09_CheckWomenOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.Navigate().GoToUrl("https://kiksha.com/women-fashion");

                string windowTitle = driver.Title;

                if (windowTitle == "WOMEN")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_10_CheckkidsOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.Navigate().GoToUrl("https://kiksha.com/kids");

                string windowTitle = driver.Title;

                if (windowTitle == "KIDS")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_11_CheckElectronicsOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.Navigate().GoToUrl("https://kiksha.com/electronics");

                string windowTitle = driver.Title;

                if (windowTitle == "ELECTRONICS")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
        static public bool TC_12_CheckLivingOption()
        {
            if (TC_01_CheckLoadingofThePage())
            {
                driver.Navigate().GoToUrl("https://kiksha.com/living");

                string windowTitle = driver.Title;

                if (windowTitle == "LIVING")
                    return true;
                else
                    return false;
            }
            else
                return false;
        }
    }
}
