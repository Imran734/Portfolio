public class LMain
{
	public static void main(String []args)
	{
		Login p = new Login();
		p.show();
	}
}